//esta clase sirve simplemente para unir las clases "funcion" y "metodo"
package Graficador;

import Graficador.funcion;
import Graficador.metodo;


public class implementacion {
    public static void main(String[] args){ //metodo publico
       funcion f= new funcion(" "); //llamado a la clace funcion
       metodo s=new metodo(); //llamado a la clace metodo
    }
    
}
