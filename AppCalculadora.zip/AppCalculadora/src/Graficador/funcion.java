
package Graficador;

import javax.swing.JOptionPane;
import org.nfunk.jep.JEP;     // CODIGO PARA IMPORTAR LAS FUNCIONES DE LA JEP

public class funcion {
    JEP j=new JEP();
    public funcion(String def){  //CONSTRUCTOR CREANDO LA DEFINICION DE LA FUNCION
    j.addVariable("x",0); // VALIDAR LA VARIABLE X
    j.addStandardConstants(); //CONNSTANTES
    j.addStandardFunctions(); //FUNCIONES
    j.parseExpression(def);
    if(j.hasError()){  //VERIFICAR SI HAY HERRORES
       System.out.print(j.getErrorInfo());  
    }
    }
    public double evaluar (double x){ //METODO PARA EVALUAR EL VALOR X
    double r; // CREAR UNA VARIABLE r
    j.addVariable("x", x); //VARIABLE X EVALUADA EN EL METODO
    r=j.getValue(); // RESULTADO DE LA OPERACION ANTERIOR, ALMACENADO EN LA VARIABLE CREADA r
    if(j.hasError()){  // ACA SE REPORTA SI HAY UN ERROR
         JOptionPane.showMessageDialog(null,"Error de Sintaxis");     //.showMessageDialog(this,"Propietario no registrado!!");
//      System.out.print(j.getErrorInfo());  
    }
    return r; // SI NO HAY ERRORES ARROJA LOQUE ESTA EN LA VARIABE r
    }
    }
    
